var searchData=
[
  ['titulo_0',['Titulo',['../class_titulo.html#ae217999bc748d8c81fa4f9fb97ef3908',1,'Titulo::Titulo()'],['../class_titulo.html#acdb8257c77b914eb9a0d27824653d53a',1,'Titulo::Titulo(string)']]]
];
