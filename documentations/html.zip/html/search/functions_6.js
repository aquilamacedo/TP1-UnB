var searchData=
[
  ['nome_0',['Nome',['../class_nome.html#a500b022728cd437dd749bfe625a26a4d',1,'Nome::Nome()'],['../class_nome.html#a5a31c8dec7272e90a3d5cb59cece8c28',1,'Nome::Nome(string)']]],
  ['nota_1',['Nota',['../class_nota.html#abaa6a5c3c58daf1030dd7b0e0930bd49',1,'Nota::Nota()'],['../class_nota.html#a4e12afab8bc85ad09654c125c45f7b91',1,'Nota::Nota(int)']]]
];
