var searchData=
[
  ['usuario_0',['Usuario',['../class_usuario.html',1,'']]]
];
