var indexSectionsWithContent =
{
  0: "acdeghinstu",
  1: "acdehinstu",
  2: "cdeghinst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

