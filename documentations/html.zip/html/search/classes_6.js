var searchData=
[
  ['nome_0',['Nome',['../class_nome.html',1,'']]],
  ['nota_1',['Nota',['../class_nota.html',1,'']]]
];
