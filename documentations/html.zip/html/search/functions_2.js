var searchData=
[
  ['email_0',['Email',['../class_email.html#a2cfcfea1e55511208e7858c33f48ad9d',1,'Email::Email()'],['../class_email.html#abfa7891fe9bc84c6f19e91a7fceb2fed',1,'Email::Email(string)']]],
  ['endereco_1',['Endereco',['../class_endereco.html#a1bb2df2319912c102821c133485bec0a',1,'Endereco::Endereco()'],['../class_endereco.html#a119a0c48e0a446e3192c2d5ab2ac61a5',1,'Endereco::Endereco(string)']]]
];
