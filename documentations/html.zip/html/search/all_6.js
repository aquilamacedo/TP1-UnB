var searchData=
[
  ['idioma_0',['Idioma',['../class_idioma.html',1,'Idioma'],['../class_idioma.html#a6722a621ce03825772493e67e5a17215',1,'Idioma::Idioma()'],['../class_idioma.html#a37e900ea308180542edd13161f8fd6a5',1,'Idioma::Idioma(string)']]]
];
